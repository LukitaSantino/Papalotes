/*
 * lcd2004a_i2c.h
 * Driver para LCD 2004A (20x4) con interfaz I2C (PCF8574)
 * Compatible con NUCLEO-H503RB
 */

#ifndef INC_LCD2004A_I2C_H_
#define INC_LCD2004A_I2C_H_

#include "stm32h5xx_hal.h"

/* Dirección I2C del LCD (puede ser 0x27 o 0x3F) */
#define LCD_I2C_ADDR     0x27 << 1  // Dirección 7-bit desplazada a 8-bit

/* Comandos del LCD HD44780 */
#define LCD_CLEAR_DISPLAY        0x01
#define LCD_RETURN_HOME          0x02
#define LCD_ENTRY_MODE_SET       0x04
#define LCD_DISPLAY_CONTROL      0x08
#define LCD_CURSOR_SHIFT         0x10
#define LCD_FUNCTION_SET         0x20
#define LCD_SET_CGRAM_ADDR       0x40
#define LCD_SET_DDRAM_ADDR       0x80

/* Flags para display entry mode */
#define LCD_ENTRY_RIGHT          0x00
#define LCD_ENTRY_LEFT           0x02
#define LCD_ENTRY_SHIFT_INCREMENT 0x01
#define LCD_ENTRY_SHIFT_DECREMENT 0x00

/* Flags para display on/off control */
#define LCD_DISPLAY_ON           0x04
#define LCD_DISPLAY_OFF          0x00
#define LCD_CURSOR_ON            0x02
#define LCD_CURSOR_OFF           0x00
#define LCD_BLINK_ON             0x01
#define LCD_BLINK_OFF            0x00

/* Flags para function set */
#define LCD_4BIT_MODE            0x00
#define LCD_2LINE                0x08
#define LCD_5x8DOTS              0x00

/* Bits del PCF8574 */
#define LCD_BACKLIGHT            0x08
#define LCD_EN                   0x04  // Enable bit
#define LCD_RW                   0x02  // Read/Write bit
#define LCD_RS                   0x01  // Register select bit

/* Direcciones DDRAM para cada línea del LCD 2004A */
#define LCD_LINE_1       0x00
#define LCD_LINE_2       0x40
#define LCD_LINE_3       0x14
#define LCD_LINE_4       0x54

/* Prototipos de funciones públicas */
void LCD_Init(I2C_HandleTypeDef *hi2c);
void LCD_Clear(void);
void LCD_Home(void);
void LCD_SetCursor(uint8_t row, uint8_t col);
void LCD_Print(char *str);
void LCD_PrintChar(char c);
void LCD_DisplayOn(void);
void LCD_DisplayOff(void);
void LCD_CursorOn(void);
void LCD_CursorOff(void);
void LCD_BlinkOn(void);
void LCD_BlinkOff(void);
void LCD_BacklightOn(void);
void LCD_BacklightOff(void);
void LCD_CreateChar(uint8_t location, uint8_t charmap[]);

#endif /* INC_LCD2004A_I2C_H_ */
