/*
 * lcd2004a_i2c.c
 * Implementación del driver para LCD 2004A (20x4) con I2C
 */

#include "lcd2004a_i2c.h"

/* Variables privadas */
static I2C_HandleTypeDef *_hi2c;
static uint8_t _displayfunction;
static uint8_t _displaycontrol;
static uint8_t _displaymode;
static uint8_t _backlightval = LCD_BACKLIGHT;

/* Funciones privadas */
static void LCD_Write4Bits(uint8_t value);
static void LCD_SendCommand(uint8_t cmd);
static void LCD_SendData(uint8_t data);
static void LCD_ExpanderWrite(uint8_t data);
static void LCD_PulseEnable(uint8_t data);

/**
 * @brief Escribe un byte al expansor I2C PCF8574
 */
static void LCD_ExpanderWrite(uint8_t data)
{
    uint8_t i2c_data = data | _backlightval;
    HAL_I2C_Master_Transmit(_hi2c, LCD_I2C_ADDR, &i2c_data, 1, 100);
}

/**
 * @brief Genera pulso en el pin Enable
 */
static void LCD_PulseEnable(uint8_t data)
{
    LCD_ExpanderWrite(data | LCD_EN);   // EN high
    HAL_Delay(1);
    LCD_ExpanderWrite(data & ~LCD_EN);  // EN low
    HAL_Delay(1);
}

/**
 * @brief Escribe 4 bits al LCD
 */
static void LCD_Write4Bits(uint8_t value)
{
    LCD_ExpanderWrite(value);
    LCD_PulseEnable(value);
}

/**
 * @brief Envía un comando al LCD
 */
static void LCD_SendCommand(uint8_t cmd)
{
    uint8_t high_nibble = cmd & 0xF0;
    uint8_t low_nibble = (cmd << 4) & 0xF0;

    LCD_Write4Bits(high_nibble);
    LCD_Write4Bits(low_nibble);

    if (cmd < 4) {
        HAL_Delay(2);  // Comandos clear y home necesitan más tiempo
    }
}

/**
 * @brief Envía datos al LCD
 */
static void LCD_SendData(uint8_t data)
{
    uint8_t high_nibble = data & 0xF0;
    uint8_t low_nibble = (data << 4) & 0xF0;

    LCD_Write4Bits(high_nibble | LCD_RS);
    LCD_Write4Bits(low_nibble | LCD_RS);
}

/**
 * @brief Inicializa el LCD en modo 4 bits vía I2C
 * @param hi2c: Puntero al handle I2C (ej: &hi2c2)
 */
void LCD_Init(I2C_HandleTypeDef *hi2c)
{
    _hi2c = hi2c;

    // Espera inicial para que el LCD se estabilice
    HAL_Delay(50);

    // Enciende el backlight
    LCD_ExpanderWrite(_backlightval);
    HAL_Delay(10);

    // Secuencia de inicialización para modo 4 bits
    LCD_Write4Bits(0x30);  // Función set
    HAL_Delay(5);

    LCD_Write4Bits(0x30);  // Función set
    HAL_Delay(1);

    LCD_Write4Bits(0x30);  // Función set
    HAL_Delay(1);

    LCD_Write4Bits(0x20);  // Cambia a modo 4 bits
    HAL_Delay(1);

    // Configuración del LCD
    _displayfunction = LCD_4BIT_MODE | LCD_2LINE | LCD_5x8DOTS;
    LCD_SendCommand(LCD_FUNCTION_SET | _displayfunction);

    // Display on, cursor off, blink off
    _displaycontrol = LCD_DISPLAY_ON | LCD_CURSOR_OFF | LCD_BLINK_OFF;
    LCD_DisplayOn();

    // Clear display
    LCD_Clear();

    // Entry mode: increment, no shift
    _displaymode = LCD_ENTRY_LEFT | LCD_ENTRY_SHIFT_DECREMENT;
    LCD_SendCommand(LCD_ENTRY_MODE_SET | _displaymode);

    HAL_Delay(10);
}

/**
 * @brief Limpia la pantalla
 */
void LCD_Clear(void)
{
    LCD_SendCommand(LCD_CLEAR_DISPLAY);
    HAL_Delay(2);
}

/**
 * @brief Regresa el cursor a home (0,0)
 */
void LCD_Home(void)
{
    LCD_SendCommand(LCD_RETURN_HOME);
    HAL_Delay(2);
}

/**
 * @brief Posiciona el cursor
 * @param row: Fila (0-3)
 * @param col: Columna (0-19)
 */
void LCD_SetCursor(uint8_t row, uint8_t col)
{
    uint8_t row_offsets[] = {LCD_LINE_1, LCD_LINE_2, LCD_LINE_3, LCD_LINE_4};

    if (row > 3) row = 3;
    if (col > 19) col = 19;

    LCD_SendCommand(LCD_SET_DDRAM_ADDR | (col + row_offsets[row]));
}

/**
 * @brief Imprime un string
 */
void LCD_Print(char *str)
{
    while (*str) {
        LCD_SendData(*str++);
    }
}

/**
 * @brief Imprime un caracter
 */
void LCD_PrintChar(char c)
{
    LCD_SendData(c);
}

/**
 * @brief Enciende el display
 */
void LCD_DisplayOn(void)
{
    _displaycontrol |= LCD_DISPLAY_ON;
    LCD_SendCommand(LCD_DISPLAY_CONTROL | _displaycontrol);
}

/**
 * @brief Apaga el display
 */
void LCD_DisplayOff(void)
{
    _displaycontrol &= ~LCD_DISPLAY_ON;
    LCD_SendCommand(LCD_DISPLAY_CONTROL | _displaycontrol);
}

/**
 * @brief Muestra el cursor
 */
void LCD_CursorOn(void)
{
    _displaycontrol |= LCD_CURSOR_ON;
    LCD_SendCommand(LCD_DISPLAY_CONTROL | _displaycontrol);
}

/**
 * @brief Oculta el cursor
 */
void LCD_CursorOff(void)
{
    _displaycontrol &= ~LCD_CURSOR_ON;
    LCD_SendCommand(LCD_DISPLAY_CONTROL | _displaycontrol);
}

/**
 * @brief Activa el parpadeo del cursor
 */
void LCD_BlinkOn(void)
{
    _displaycontrol |= LCD_BLINK_ON;
    LCD_SendCommand(LCD_DISPLAY_CONTROL | _displaycontrol);
}

/**
 * @brief Desactiva el parpadeo del cursor
 */
void LCD_BlinkOff(void)
{
    _displaycontrol &= ~LCD_BLINK_ON;
    LCD_SendCommand(LCD_DISPLAY_CONTROL | _displaycontrol);
}

/**
 * @brief Enciende el backlight
 */
void LCD_BacklightOn(void)
{
    _backlightval = LCD_BACKLIGHT;
    LCD_ExpanderWrite(0);
}

/**
 * @brief Apaga el backlight
 */
void LCD_BacklightOff(void)
{
    _backlightval = 0;
    LCD_ExpanderWrite(0);
}

/**
 * @brief Crea un caracter personalizado
 * @param location: Ubicación (0-7)
 * @param charmap: Array de 8 bytes definiendo el caracter
 */
void LCD_CreateChar(uint8_t location, uint8_t charmap[])
{
    location &= 0x7; // Solo tenemos 8 ubicaciones (0-7)
    LCD_SendCommand(LCD_SET_CGRAM_ADDR | (location << 3));

    for (int i = 0; i < 8; i++) {
        LCD_SendData(charmap[i]);
    }
}
