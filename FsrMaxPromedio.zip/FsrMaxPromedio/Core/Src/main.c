/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : FSR con MAX30102 - Cálculo de Ritmo Cardíaco
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <string.h>
#include "lcd2004a_i2c.h"
#include "max30102.h"
#include "heartrate.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
typedef enum {
    STATE_WAITING,      // Esperando presión en FSR
    STATE_READING,      // Leyendo MAX30102
    STATE_STOPPED       // Lectura detenida
} SystemState_t;
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define FSR_THRESHOLD 30.0f          // Umbral de presión para activar (%)
#define FSR_RELEASE_THRESHOLD 20.0f  // Umbral para detectar liberación (%)
#define READING_DURATION 30000        // Duración máxima: 30 segundos
#define FSR_DEBOUNCE_COUNT 3         // Lecturas consecutivas para confirmar estado

// Parámetros para cálculo de ritmo cardíaco
#define RATE_SIZE 4                  // Número de muestras para promedio BPM
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc1;

I2C_HandleTypeDef hi2c1;

TIM_HandleTypeDef htim6;

UART_HandleTypeDef huart3;

/* USER CODE BEGIN PV */
uint32_t adc_value = 0;
float voltage = 0.0f;
float force_estimate = 0.0f;
char msg[100];
char lcd_line[21];

// Variables del sistema de estados
SystemState_t system_state = STATE_WAITING;
uint32_t reading_start_time = 0;

// Variables de debounce del FSR
uint8_t fsr_pressed_count = 0;
uint8_t fsr_released_count = 0;

// Variables del MAX30102
MAX30105_t particleSensor;
uint8_t max30102_initialized = 0;

// Variables para cálculo de ritmo cardíaco (igual que el código de referencia)
uint8_t rates[RATE_SIZE];            // Array de frecuencias cardíacas
uint8_t rateSpot = 0;
uint32_t lastBeat = 0;               // Tiempo en que ocurrió el último latido
float beatsPerMinute = 0;
int beatAvg = 0;

// Variables para control de tiempo
uint32_t lastPrintTime = 0;
uint32_t lastLcdUpdate = 0;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_TIM6_Init(void);
static void MX_ADC1_Init(void);
static void MX_I2C1_Init(void);
static void MX_USART3_UART_Init(void);
/* USER CODE BEGIN PFP */
float Calculate_Force(uint32_t adc_val);
void LCD_DisplayBarGraph(uint8_t row, float percent);
void Reset_HeartRate_Calculation(void);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM6_Init();
  MX_ADC1_Init();
  MX_I2C1_Init();
  MX_USART3_UART_Init();
  /* USER CODE BEGIN 2 */

  // Calibrar el ADC
  HAL_ADCEx_Calibration_Start(&hadc1, ADC_SINGLE_ENDED);

  // Inicializar LCD
  LCD_Init(&hi2c1);
  HAL_Delay(100);

  // Pantalla de inicio
  LCD_Clear();
  LCD_SetCursor(0, 2);
  LCD_Print("SISTEMA CARDIACO");
  LCD_SetCursor(1, 3);
  LCD_Print("FSR + MAX30102");
  LCD_SetCursor(2, 2);
  LCD_Print("Nucleo H503RB");
  LCD_SetCursor(3, 3);
  LCD_Print("Iniciando...");
  HAL_Delay(2000);

  // Mensaje por UART
  sprintf(msg, "\r\n===== SISTEMA DE MONITOREO CARDIACO =====\r\n");
  HAL_UART_Transmit(&huart3, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);
  sprintf(msg, "FSR + MAX30102 Heart Rate Monitor\r\n");
  HAL_UART_Transmit(&huart3, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);
  sprintf(msg, "==========================================\r\n\r\n");
  HAL_UART_Transmit(&huart3, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);

  // Inicializar MAX30102
  if (!MAX30105_begin(&particleSensor, &hi2c1, MAX30105_ADDRESS)) {
      sprintf(msg, "ERROR: MAX30102 no encontrado!\r\n");
      HAL_UART_Transmit(&huart3, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);

      LCD_Clear();
      LCD_SetCursor(1, 2);
      LCD_Print("ERROR MAX30102");
      LCD_SetCursor(2, 1);
      LCD_Print("Verifique I2C");

      while (1) {
          HAL_GPIO_TogglePin(LED_GREEN_GPIO_Port, LED_GREEN_Pin);
          HAL_Delay(200);
      }
  }

  sprintf(msg, "MAX30102 inicializado!\r\n");
  HAL_UART_Transmit(&huart3, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);
  sprintf(msg, "Revision ID: 0x%02X\r\n", MAX30105_getRevisionID(&particleSensor));
  HAL_UART_Transmit(&huart3, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);
  sprintf(msg, "Part ID: 0x%02X\r\n\r\n", MAX30105_readPartID(&particleSensor));
  HAL_UART_Transmit(&huart3, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);

  // Configurar sensor (igual que el código de referencia)
  MAX30105_setup(&particleSensor, 0x1F, 4, 2, 100, 411, 4096);

  sprintf(msg, "Sensor configurado:\r\n");
  HAL_UART_Transmit(&huart3, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);
  sprintf(msg, "  - LED Mode: Red + IR\r\n");
  HAL_UART_Transmit(&huart3, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);
  sprintf(msg, "  - Sample Rate: 100 Hz\r\n");
  HAL_UART_Transmit(&huart3, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);
  sprintf(msg, "  - Pulse Width: 411 us\r\n");
  HAL_UART_Transmit(&huart3, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);
  sprintf(msg, "  - ADC Range: 4096\r\n\r\n");
  HAL_UART_Transmit(&huart3, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);

  // Inicializar algoritmo de detección de latidos
  heartRate_init();
  max30102_initialized = 1;

  sprintf(msg, "Algoritmo PBA inicializado\r\n\r\n");
  HAL_UART_Transmit(&huart3, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);

  // Configurar pantalla de espera
  LCD_Clear();
  LCD_SetCursor(0, 0);
  LCD_Print("Esperando presion...");
  LCD_SetCursor(1, 0);
  LCD_Print("Fuerza:");
  LCD_SetCursor(2, 0);
  LCD_Print("Estado: ESPERANDO");
  LCD_SetCursor(3, 0);
  LCD_Print("Barra:");

  sprintf(msg, ">>> Presione el FSR para iniciar <<<\r\n\r\n");
  HAL_UART_Transmit(&huart3, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);

  HAL_Delay(500);

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

    // ========== LEER FSR ==========
    HAL_ADC_Start(&hadc1);
    if (HAL_ADC_PollForConversion(&hadc1, 50) == HAL_OK)
    {
      adc_value = HAL_ADC_GetValue(&hadc1);
      voltage = (adc_value * 3.3f) / 4095.0f;
      force_estimate = Calculate_Force(adc_value);
    }
    HAL_ADC_Stop(&hadc1);

    // ========== MÁQUINA DE ESTADOS ==========
    switch(system_state)
    {
      case STATE_WAITING:
        // Actualizar display básico del FSR
        LCD_SetCursor(1, 8);
        sprintf(lcd_line, "%5.1f%%   ", force_estimate);
        LCD_Print(lcd_line);
        LCD_DisplayBarGraph(3, force_estimate);

        // LED indicador de presión suficiente
        if(force_estimate > FSR_THRESHOLD)
        {
          HAL_GPIO_WritePin(LED_GREEN_GPIO_Port, LED_GREEN_Pin, GPIO_PIN_SET);
          fsr_pressed_count++;
          fsr_released_count = 0;
        }
        else
        {
          HAL_GPIO_WritePin(LED_GREEN_GPIO_Port, LED_GREEN_Pin, GPIO_PIN_RESET);
          fsr_pressed_count = 0;
          fsr_released_count++;
        }

        // Verificar si se debe iniciar lectura (con debounce)
        if(fsr_pressed_count >= FSR_DEBOUNCE_COUNT && max30102_initialized)
        {
          system_state = STATE_READING;
          reading_start_time = HAL_GetTick();
          lastPrintTime = HAL_GetTick();
          lastLcdUpdate = HAL_GetTick();

          // Resetear cálculo de ritmo cardíaco
          Reset_HeartRate_Calculation();

          // Pantalla de lectura
          LCD_Clear();
          LCD_SetCursor(0, 2);
          LCD_Print("*** LEYENDO ***");
          LCD_SetCursor(1, 0);
          LCD_Print("BPM:");
          LCD_SetCursor(2, 0);
          LCD_Print("IR:");
          LCD_SetCursor(3, 0);
          LCD_Print("Dedo:");

          sprintf(msg, "\r\n========== LECTURA INICIADA ==========\r\n");
          HAL_UART_Transmit(&huart3, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);

          fsr_pressed_count = 0;
          fsr_released_count = 0;
        }
        break;

      case STATE_READING:
        // *** VERIFICACIÓN INMEDIATA DE LIBERACIÓN DEL FSR ***
        if(force_estimate < FSR_RELEASE_THRESHOLD)
        {
          fsr_released_count++;
          fsr_pressed_count = 0;

          if(fsr_released_count >= FSR_DEBOUNCE_COUNT)
          {
            // FSR liberado - terminar lectura
            system_state = STATE_STOPPED;

            LCD_Clear();
            LCD_SetCursor(0, 3);
            LCD_Print("FSR LIBERADO");
            LCD_SetCursor(1, 0);
            if(beatAvg > 0)
            {
              sprintf(lcd_line, "BPM Final: %d", beatAvg);
            }
            else
            {
              sprintf(lcd_line, "BPM Final: ---");
            }
            LCD_Print(lcd_line);
            LCD_SetCursor(2, 1);
            sprintf(lcd_line, "Tiempo: %lu s", (HAL_GetTick() - reading_start_time) / 1000);
            LCD_Print(lcd_line);

            sprintf(msg, "\r\n>>> FSR LIBERADO - Lectura terminada <<<\r\n");
            HAL_UART_Transmit(&huart3, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);
            if(beatAvg > 0)
            {
              sprintf(msg, "BPM promedio: %d\r\n", beatAvg);
            }
            else
            {
              sprintf(msg, "BPM promedio: No calculado\r\n");
            }
            HAL_UART_Transmit(&huart3, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);
            sprintf(msg, "======================================\r\n\r\n");
            HAL_UART_Transmit(&huart3, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);

            break;
          }
        }
        else
        {
          fsr_released_count = 0;
          fsr_pressed_count++;
        }

        // Verificar tiempo máximo de lectura
        if((HAL_GetTick() - reading_start_time) > READING_DURATION)
        {
          system_state = STATE_STOPPED;

          LCD_Clear();
          LCD_SetCursor(0, 2);
          LCD_Print("TIEMPO COMPLETO");
          LCD_SetCursor(1, 0);
          if(beatAvg > 0)
          {
            sprintf(lcd_line, "BPM: %d", beatAvg);
          }
          else
          {
            sprintf(lcd_line, "BPM: ---");
          }
          LCD_Print(lcd_line);
          LCD_SetCursor(2, 2);
          LCD_Print("30 segundos");

          sprintf(msg, "\r\n>>> TIEMPO MÁXIMO ALCANZADO <<<\r\n");
          HAL_UART_Transmit(&huart3, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);
          if(beatAvg > 0)
          {
            sprintf(msg, "BPM promedio: %d\r\n", beatAvg);
          }
          else
          {
            sprintf(msg, "BPM promedio: No calculado\r\n");
          }
          HAL_UART_Transmit(&huart3, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);
          sprintf(msg, "====================================\r\n\r\n");
          HAL_UART_Transmit(&huart3, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);
        }
        else
        {
          // ========== LEER MAX30102 (EXACTAMENTE COMO EL CÓDIGO DE REFERENCIA) ==========
          uint32_t irValue = MAX30105_getIR(&particleSensor);

          // Verificar si hay dedo detectado (IR > 50000)
          if (irValue < 50000) {
              // No hay dedo detectado
              beatAvg = 0;

              // Actualizar LCD cada 500ms
              if (HAL_GetTick() - lastLcdUpdate > 500) {
                  LCD_SetCursor(1, 5);
                  LCD_Print("---     ");
                  LCD_SetCursor(2, 4);
                  sprintf(lcd_line, "%lu      ", irValue);
                  LCD_Print(lcd_line);
                  LCD_SetCursor(3, 6);
                  LCD_Print("NO DETECTADO");

                  lastLcdUpdate = HAL_GetTick();
              }

              // Parpadear LED lentamente
              if (HAL_GetTick() - lastPrintTime > 1000) {
                  HAL_GPIO_TogglePin(LED_GREEN_GPIO_Port, LED_GREEN_Pin);

                  sprintf(msg, "No finger (IR: %lu)\r\n", irValue);
                  HAL_UART_Transmit(&huart3, (uint8_t*)msg, strlen(msg), 100);

                  lastPrintTime = HAL_GetTick();
              }
          }
          else {
              // ¡Dedo detectado!
              HAL_GPIO_WritePin(LED_GREEN_GPIO_Port, LED_GREEN_Pin, GPIO_PIN_SET);

              // Verificar latido (EXACTAMENTE como el código de referencia)
              if (checkForBeat(irValue) == true) {
                  // ¡Latido detectado!

                  // Calcular tiempo entre latidos
                  uint32_t delta = HAL_GetTick() - lastBeat;
                  lastBeat = HAL_GetTick();

                  // Calcular BPM
                  beatsPerMinute = 60000.0 / (float)delta;

                  // Filtrar rango válido (20-255 BPM)
                  if (beatsPerMinute < 255 && beatsPerMinute > 20) {
                      // Guardar lectura en el array
                      rates[rateSpot++] = (uint8_t)beatsPerMinute;
                      rateSpot %= RATE_SIZE;

                      // Calcular promedio
                      beatAvg = 0;
                      for (uint8_t x = 0; x < RATE_SIZE; x++) {
                          beatAvg += rates[x];
                      }
                      beatAvg /= RATE_SIZE;

                      // Imprimir información del latido
                      sprintf(msg, "♥ BEAT! IR: %6lu | BPM: %3.1f | Avg: %3d\r\n",
                              irValue, beatsPerMinute, beatAvg);
                      HAL_UART_Transmit(&huart3, (uint8_t*)msg, strlen(msg), 100);

                      // Parpadeo rápido del LED
                      HAL_GPIO_WritePin(LED_GREEN_GPIO_Port, LED_GREEN_Pin, GPIO_PIN_RESET);
                      HAL_Delay(50);
                      HAL_GPIO_WritePin(LED_GREEN_GPIO_Port, LED_GREEN_Pin, GPIO_PIN_SET);

                      // Actualizar LCD inmediatamente
                      LCD_SetCursor(1, 5);
                      sprintf(lcd_line, "%d      ", beatAvg);
                      LCD_Print(lcd_line);
                      LCD_SetCursor(2, 4);
                      sprintf(lcd_line, "%lu      ", irValue);
                      LCD_Print(lcd_line);
                      LCD_SetCursor(3, 6);
                      LCD_Print("DETECTADO  ");

                      lastLcdUpdate = HAL_GetTick();
                  }
              }

              // Actualizar LCD cada segundo
              if (HAL_GetTick() - lastLcdUpdate > 1000) {
                  LCD_SetCursor(2, 4);
                  sprintf(lcd_line, "%lu      ", irValue);
                  LCD_Print(lcd_line);
                  LCD_SetCursor(3, 6);
                  LCD_Print("DETECTADO  ");

                  sprintf(msg, "IR: %lu | Avg BPM: %d\r\n", irValue, beatAvg);
                  HAL_UART_Transmit(&huart3, (uint8_t*)msg, strlen(msg), 100);

                  lastLcdUpdate = HAL_GetTick();
              }
          }
        }
        break;

      case STATE_STOPPED:
        // Esperar a que se libere completamente el FSR
        if(force_estimate < FSR_RELEASE_THRESHOLD)
        {
          fsr_released_count++;

          if(fsr_released_count >= FSR_DEBOUNCE_COUNT)
          {
            system_state = STATE_WAITING;

            LCD_Clear();
            LCD_SetCursor(0, 0);
            LCD_Print("Esperando presion...");
            LCD_SetCursor(1, 0);
            LCD_Print("Fuerza:");
            LCD_SetCursor(2, 0);
            LCD_Print("Estado: LISTO");
            LCD_SetCursor(3, 0);
            LCD_Print("Barra:");

            sprintf(msg, ">>> Sistema listo - Presione FSR <<<\r\n\r\n");
            HAL_UART_Transmit(&huart3, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);

            fsr_pressed_count = 0;
            fsr_released_count = 0;
          }
        }
        else
        {
          fsr_released_count = 0;
        }
        break;
    }

    HAL_Delay(20); // 20ms = ~50Hz de muestreo
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);

  while(!__HAL_PWR_GET_FLAG(PWR_FLAG_VOSRDY)) {}

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_CSI;
  RCC_OscInitStruct.CSIState = RCC_CSI_ON;
  RCC_OscInitStruct.CSICalibrationValue = RCC_CSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLL1_SOURCE_CSI;
  RCC_OscInitStruct.PLL.PLLM = 1;
  RCC_OscInitStruct.PLL.PLLN = 50;
  RCC_OscInitStruct.PLL.PLLP = 2;
  RCC_OscInitStruct.PLL.PLLQ = 2;
  RCC_OscInitStruct.PLL.PLLR = 2;
  RCC_OscInitStruct.PLL.PLLRGE = RCC_PLL1_VCIRANGE_2;
  RCC_OscInitStruct.PLL.PLLVCOSEL = RCC_PLL1_VCORANGE_WIDE;
  RCC_OscInitStruct.PLL.PLLFRACN = 0;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2
                              |RCC_CLOCKTYPE_PCLK3;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB3CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure the programming delay
  */
  __HAL_FLASH_SET_PROGRAM_DELAY(FLASH_PROGRAMMING_DELAY_2);
}

/**
  * @brief ADC1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC1_Init(void)
{

  /* USER CODE BEGIN ADC1_Init 0 */

  /* USER CODE END ADC1_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC1_Init 1 */

  /* USER CODE END ADC1_Init 1 */

  /** Common config
  */
  hadc1.Instance = ADC1;
  hadc1.Init.ClockPrescaler = ADC_CLOCK_ASYNC_DIV4;
  hadc1.Init.Resolution = ADC_RESOLUTION_12B;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.ScanConvMode = ADC_SCAN_DISABLE;
  hadc1.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  hadc1.Init.LowPowerAutoWait = DISABLE;
  hadc1.Init.ContinuousConvMode = DISABLE;
  hadc1.Init.NbrOfConversion = 1;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc1.Init.DMAContinuousRequests = DISABLE;
  hadc1.Init.SamplingMode = ADC_SAMPLING_MODE_NORMAL;
  hadc1.Init.Overrun = ADC_OVR_DATA_PRESERVED;
  hadc1.Init.OversamplingMode = DISABLE;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_0;
  sConfig.Rank = ADC_REGULAR_RANK_1;
  sConfig.SamplingTime = ADC_SAMPLETIME_2CYCLES_5;
  sConfig.SingleDiff = ADC_SINGLE_ENDED;
  sConfig.OffsetNumber = ADC_OFFSET_NONE;
  sConfig.Offset = 0;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC1_Init 2 */

  /* USER CODE END ADC1_Init 2 */

}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.Timing = 0x10C0ECFF;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Analogue filter
  */
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c1, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Digital filter
  */
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c1, 0) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief TIM6 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM6_Init(void)
{

  /* USER CODE BEGIN TIM6_Init 0 */

  /* USER CODE END TIM6_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM6_Init 1 */

  /* USER CODE END TIM6_Init 1 */
  htim6.Instance = TIM6;
  htim6.Init.Prescaler = 999;
  htim6.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim6.Init.Period = 999;
  htim6.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim6) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim6, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM6_Init 2 */

  /* USER CODE END TIM6_Init 2 */

}

/**
  * @brief USART3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART3_UART_Init(void)
{

  /* USER CODE BEGIN USART3_Init 0 */

  /* USER CODE END USART3_Init 0 */

  /* USER CODE BEGIN USART3_Init 1 */

  /* USER CODE END USART3_Init 1 */
  huart3.Instance = USART3;
  huart3.Init.BaudRate = 115200;
  huart3.Init.WordLength = UART_WORDLENGTH_8B;
  huart3.Init.StopBits = UART_STOPBITS_1;
  huart3.Init.Parity = UART_PARITY_NONE;
  huart3.Init.Mode = UART_MODE_TX_RX;
  huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart3.Init.OverSampling = UART_OVERSAMPLING_16;
  huart3.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart3.Init.ClockPrescaler = UART_PRESCALER_DIV1;
  huart3.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart3) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetTxFifoThreshold(&huart3, UART_TXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetRxFifoThreshold(&huart3, UART_RXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_DisableFifoMode(&huart3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART3_Init 2 */

  /* USER CODE END USART3_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */

/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LED_GREEN_GPIO_Port, LED_GREEN_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : USER_BUTTON_Pin */
  GPIO_InitStruct.Pin = USER_BUTTON_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(USER_BUTTON_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : LED_GREEN_Pin */
  GPIO_InitStruct.Pin = LED_GREEN_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LED_GREEN_GPIO_Port, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/**
  * @brief  Resetea variables del cálculo de ritmo cardíaco
  */
void Reset_HeartRate_Calculation(void)
{
  for(int i = 0; i < RATE_SIZE; i++)
  {
    rates[i] = 0;
  }

  rateSpot = 0;
  lastBeat = 0;
  beatsPerMinute = 0.0f;
  beatAvg = 0;

  // Reinicializar algoritmo PBA
  heartRate_init();
}

/**
  * @brief  Calcula el porcentaje de fuerza basado en el valor del ADC
  */
float Calculate_Force(uint32_t adc_val)
{
  const uint32_t ADC_MIN_THRESHOLD = 50;
  const uint32_t ADC_MAX_VALUE = 3900;

  if (adc_val < ADC_MIN_THRESHOLD)
  {
    return 0.0f;
  }

  if (adc_val > ADC_MAX_VALUE)
  {
    return 100.0f;
  }

  float force_percent = ((adc_val - ADC_MIN_THRESHOLD) * 100.0f) /
                        (ADC_MAX_VALUE - ADC_MIN_THRESHOLD);

  return force_percent;
}

/**
  * @brief  Muestra una barra gráfica en el LCD
  */
void LCD_DisplayBarGraph(uint8_t row, float percent)
{
  int filled = (int)((percent / 100.0f) * 14);

  LCD_SetCursor(row, 6);

  for(int i = 0; i < 14; i++)
  {
    if(i < filled)
      LCD_PrintChar(0xFF);
    else
      LCD_PrintChar('-');
  }
}

/* Redirigir printf a UART */
int _write(int file, char *ptr, int len)
{
  HAL_UART_Transmit(&huart3, (uint8_t*)ptr, len, HAL_MAX_DELAY);
  return len;
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  __disable_irq();
  while (1)
  {
    HAL_GPIO_TogglePin(LED_GREEN_GPIO_Port, LED_GREEN_Pin);
    HAL_Delay(100);
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
