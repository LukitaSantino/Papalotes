/*
 Optical Heart Rate Detection (PBA Algorithm)
 By: Nathan Seidle
 SparkFun Electronics
 Date: October 2nd, 2016
 Adapted for STM32 HAL: 2024

 Given a series of IR samples from the MAX30105 we discern when a heart beat is occurring

 Let's have a brief chat about what this code does. We're going to try to detect
 heart-rate optically. This is tricky and prone to give false readings. We really don't
 want to get anyone hurt so use this code only as an example of how to process optical
 data. Build fun stuff with our MAX30105 breakout board but don't use it for actual
 medical diagnosis.

 Excellent background on optical heart rate detection:
 http://www.ti.com/lit/an/slaa655/slaa655.pdf

 Good reading:
 http://www.techforfuture.nl/fjc_documents/mitrabaratchi-measuringheartratewithopticalsensor.pdf
 https://fruct.org/publications/fruct13/files/Lau.pdf

 This is an implementation of Maxim's PBA (Peripheral Beat Amplitude) algorithm.
*/

/* Copyright (C) 2016 Maxim Integrated Products, Inc., All Rights Reserved.
*
* Permission is hereby granted, free of charge, to any person obtaining a
* copy of this software and associated documentation files (the "Software"),
* to deal in the Software without restriction, including without limitation
* the rights to use, copy, modify, merge, publish, distribute, sublicense,
* and/or sell copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included
* in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
* OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
* MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
* IN NO EVENT SHALL MAXIM INTEGRATED BE LIABLE FOR ANY CLAIM, DAMAGES
* OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
* ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*
* Except as contained in this notice, the name of Maxim Integrated
* Products, Inc. shall not be used except as stated in the Maxim Integrated
* Products, Inc. Branding Policy.
*
* The mere transfer of this software does not imply any licenses
* of trade secrets, proprietary technology, copyrights, patents,
* trademarks, maskwork rights, or any other form of intellectual
* property whatsoever. Maxim Integrated Products, Inc. retains all
* ownership rights.
*
*/

#ifndef HEARTRATE_H_
#define HEARTRATE_H_

#include <stdint.h>
#include <stdbool.h>

// Heart Rate Detection Functions

/**
 * @brief Check if a heart beat is detected in the current sample
 * @param sample IR sensor sample value
 * @return true if a beat is detected, false otherwise
 * @note A running average of four samples is recommended for display
 */
bool checkForBeat(int32_t sample);

/**
 * @brief Average DC Estimator - removes DC component from signal
 * @param p Pointer to accumulator register
 * @param x Input sample
 * @return Estimated DC average
 */
int16_t averageDCEstimator(int32_t *p, uint16_t x);

/**
 * @brief Low Pass FIR Filter - smooths the AC signal
 * @param din Input data (AC component)
 * @return Filtered output
 */
int16_t lowPassFIRFilter(int16_t din);

/**
 * @brief Integer multiplication helper function
 * @param x First operand
 * @param y Second operand
 * @return Product of x and y as 32-bit integer
 */
int32_t mul16(int16_t x, int16_t y);

/**
 * @brief Reset/initialize the heart rate detection algorithm
 * @note Call this before starting a new heart rate measurement session
 */
void heartRate_init(void);

#endif /* HEARTRATE_H_ */
